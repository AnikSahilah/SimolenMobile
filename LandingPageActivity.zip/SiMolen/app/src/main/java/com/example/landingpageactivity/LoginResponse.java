package com.example.landingpageactivity;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class LoginResponse {
    private boolean status;
    private String message;
    private UserData data;

    // Getter methods
    public boolean getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public UserData getData() {
        return data;
    }
}

