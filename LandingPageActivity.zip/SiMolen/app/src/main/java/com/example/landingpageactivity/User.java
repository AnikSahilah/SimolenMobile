package com.example.landingpageactivity;

public class User {
    private int id;
    private String name;
    private String email;
    private String role;
    private String alamat;
    private String no_hp;
    private String jenis_kelamin;

    // Getter methods
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getRole() {
        return role;
    }

    public String getAlamat() {
        return alamat;
    }

    public String getNoHp() {
        return no_hp;
    }

    public String getJenisKelamin() {
        return jenis_kelamin;
    }
}
