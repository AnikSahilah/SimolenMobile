package com.example.landingpageactivity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class PemesananBarangActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pemesanan_barang);
        getSupportActionBar().hide();
    }
}