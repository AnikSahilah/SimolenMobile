package com.example.landingpageactivity;

public class UserData {
    private User user;
    private String token;

    // Getter methods
    public User getUser() {
        return user;
    }

    public String getToken() {
        return token;
    }
}
