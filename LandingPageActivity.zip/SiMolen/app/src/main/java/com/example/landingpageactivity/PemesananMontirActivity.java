package com.example.landingpageactivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class PemesananMontirActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pemesanan_montir);
        getSupportActionBar().hide();

        String list[]={"mobil","motor"};
        Spinner spinner = (Spinner) findViewById(R.id.spiner1);
        ArrayAdapter<String> AdapterList = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,list);
        spinner.setAdapter(AdapterList);
    }
}