package com.example.landingpageactivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class DashboardCustomerActivity extends AppCompatActivity {
    ImageView image;
    SessionManager sessionManager;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_customer);
        sessionManager = new SessionManager(this);
        image = findViewById(R.id.simage);

        SharedPreferences sharedPreferences = DashboardCustomerActivity.this.getSharedPreferences("SIMOLEN", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editor.remove("SIMOLEN");
                editor.apply();
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }
        });
        getSupportActionBar().hide();
    }

}